# OS-Simulation :computer:
An architecture that simulates a real operating system.

<h2> The Main Parts Implemented for this project </h2>
&nbsp;&nbsp;&nbsp; • Code Parser/Interpeter <br>
&nbsp;&nbsp;&nbsp; • System Calls <br>
&nbsp;&nbsp;&nbsp; • Mutexes <br>
&nbsp;&nbsp;&nbsp; • Scheduler <br>
&nbsp;&nbsp;&nbsp; • Memory Management <br>
&nbsp;&nbsp;&nbsp; • Process Control Block <br>
